package com.example.countriesinfoapp;

public class Place {
    String placeCount;
    String placeName;
    double placePrice;
    String placeImg;

    public Place(String placeCount, String placeName, double placePrice,String placeImg) {
        this.placeCount = placeCount;
        this.placeName = placeName;
        this.placePrice = placePrice;
        this.placeImg = placeImg;
    }

    public String getPlaceCount() {
        return placeCount;
    }

    public String getPlaceName() {
        return placeName;
    }

    public double getPlacePrice() {
        return placePrice;
    }


    public String getPlaceImg() {
        return placeImg;
    }
}




