package com.example.countriesinfoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    TextView welcomeMember;
    Spinner sp;
    ListView lv;
    Button total;
    SeekBar seek;
    ImageView img;
    TextView capital,amount,visitors;

    public static double Total=0;
    ArrayList<Place> placeList = new ArrayList<>();
    ArrayList<Place>tempList = new ArrayList<>();
    String count[]={"Canada","USA","England"};

    public void fillData(){
        placeList.add(new Place(count[0],"Niagara Falls",100,"niagarafalls"));
        placeList.add(new Place(count[0],"CN Tower ",30,"cntower"));
        placeList.add(new Place(count[0],"The Butchart Gardens",30,"butchart"));
        placeList.add(new Place(count[0],"Notre-Dame Basilica",50,"notredame"));

        placeList.add(new Place(count[1],"The Statue Of Liberty ",90,"statueofliberty"));
        placeList.add(new Place(count[1],"The White House ",60,"whitehouse"));
        placeList.add(new Place(count[1],"Tims Square ",75,"timssquare"));
        placeList.add(new Place(count[2],"Big Ben ",30,"bigben"));
        placeList.add(new Place(count[2],"Westminister Abbey ",25,"westminister"));
        placeList.add(new Place(count[2],"Hyde Park ",15,"hydepark"));

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        welcomeMember = findViewById(R.id.welcomeMsg);
        welcomeMember.setText("Welcome back " + LoginActivity.memberName);
        fillData();
        sp = findViewById(R.id.countrySP);
        lv = findViewById(R.id.placeLV);
        seek = findViewById(R.id.placeSB);
        visitors = findViewById(R.id.txtVisitor);
        amount = findViewById(R.id.txtAmount);
        img = findViewById(R.id.imgCountry);
        total = findViewById(R.id.btnTotal);
        capital = findViewById(R.id.txtCapital);

        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, count);
        sp.setAdapter(aa);
        sp.setOnItemSelectedListener(this);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Total=tempList.get(i).placePrice;
                amount.setText(String.format("%.2f",total));
            }
        });
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(i>=1)
                    visitors.setText(String.valueOf(i));
                else
                    visitors.setText("1");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        total.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

            }
        });
    }
    public void fillTempList(String count){
        for (int i=0;i<placeList.size();i++)
            if(count.equals(placeList.get(i).placeCount))
                tempList.add(placeList.get(i));

    }
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tempList.clear();
                fillTempList(count[i]);

                lv.setAdapter(new PlaceAdapter(this,tempList));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }



}

