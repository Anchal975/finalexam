package com.example.countriesinfoapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintSet;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PlaceAdapter extends BaseAdapter {
    private ArrayList<Place> places;
    private LayoutInflater inflater;

    public PlaceAdapter(Context context, ArrayList<Place>places) {
        this.places = places;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return places.size();
    }

    @Override
    public Object getItem(int i) {
        return places.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder = new ViewHolder();
        if (view == null) {
             view=inflater.inflate(R.layout.list_row,null);

            holder.pPrice = view.findViewById(R.id.txtPrice);
            holder.pName = view.findViewById(R.id.txtName);
            holder.img = view.findViewById(R.id.imgPlace);
            view.setTag(holder);

        } else
            view.getTag();
        int id = view.getResources().getIdentifier(places.get(i).placeImg,"mipmap",view.getContext().getPackageName());
        holder.img.setImageResource(id);
        holder.pName.setText(places.get(i).placeName);
        holder.pPrice.setText(String.valueOf(places.get(i).getPlacePrice()));


        return view;
    }
    static class ViewHolder{
        ImageView img;
        TextView pName,pPrice;


    }
}
